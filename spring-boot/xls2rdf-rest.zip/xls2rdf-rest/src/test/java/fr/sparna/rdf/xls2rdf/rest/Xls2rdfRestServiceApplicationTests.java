package fr.sparna.rdf.xls2rdf.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xls2rdfRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
